package dao;

public interface ContactManagementDAO {
    void viewContract();
    void add();
    void editInformation();
    void delete();
    void search();
}
